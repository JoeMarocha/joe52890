package pl.vistula;

public interface Calculator {

    public double add(double first, double second);

    public double sub(double first, double second);

    public double mul(double first, double second);

    public double div(double first, double second);

}
